package com.browserstack;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class BStackDemoTest extends SeleniumTest {
	 // Ensure you have a WebDriver instance
    //private JavascriptExecutor js;
	
//    @Test(priority = 0)
//    public void launchWebsite() throws InterruptedException {
//        driver.get("https://store.standards.org.au/reader/as-3633-1989?preview=1");
//        
//        // Take an initial screenshot
//        PercySDK.screenshot(driver, "name");
//        
//        // Create a JavascriptExecutor instance
//        JavascriptExecutor js = (JavascriptExecutor) driver;
//
//        // Scroll the specific element
//        js.executeScript("document.getElementById('ereader-content').scrollBy(0, 20000);");
//
//        // Optionally wait to see the scroll effect, if necessary
//        Thread.sleep(2000); // Adjust this as needed
//
//        // Take a screenshot after scrolling
//        PercySDK.screenshot(driver, "afterscroll");
//    }
	
	@Test
	public void launchWebsite() throws InterruptedException {
	    driver.get("https://store.standards.org.au/reader/as-3633-1989?preview=1");
	    
	    // Take an initial screenshot
	    PercySDK.screenshot(driver, "initial_screenshot");

	    // Create a JavascriptExecutor instance
	    JavascriptExecutor js = (JavascriptExecutor) driver;

	    // Initialize variables for scrolling
	    Long previousScrollHeight = 0L;
	    Long currentScrollHeight = (Long) js.executeScript("return document.getElementById('ereader-content').scrollHeight;");
	    int screenshotCount = 1; // Start counting screenshots

	    // Scroll until the end of the content
	    while (true) {
	        // Take a screenshot at the current position
	        PercySDK.screenshot(driver, "screenshot_" + screenshotCount);
	        
	        // Scroll down
	        js.executeScript("document.getElementById('ereader-content').scrollBy(0, 500);");
	        
	        // Wait for a moment to allow content to load
	        Thread.sleep(1000); // Adjust as necessary
	        
	        // Update scroll heights
	        previousScrollHeight = currentScrollHeight;
	        currentScrollHeight = (Long) js.executeScript("return document.getElementById('ereader-content').scrollHeight;");
	        
	        if (screenshotCount > 10) {
	            break; // Exit the loop if no more content is loaded or if too many screenshots have been taken
	        }

	        screenshotCount++; // Increment screenshot count
	    }

	    // Optional: Final screenshot after scrolling is complete
	    //PercySDK.screenshot(driver, "final_screenshot");
	}


}

    

